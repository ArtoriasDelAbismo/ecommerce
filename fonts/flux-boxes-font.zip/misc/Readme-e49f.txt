===================================================== 
Thank You for Downloading Our Font!
Hi there! Thank you so much for your support.

This font is 100% FREE for all PERSONAL USE.
Have fun using it for your non-commercial projects!
------------------------------------------------------------------------------------------
UNLOCK THE FULL COMMERCIAL POWER
If you love this font, unlock its full potential for your brand with our Professional License.

Our Professional License is a one-time investment that gives you lifetime creative freedom. 
Here is everything included:

✅ LIFETIME LICENSE & ONE-TIME PAYMENT. 
Pay once, own it forever. No subscription fees, ever.

✅ FULL LOGO & BRANDING RIGHTS
Perfect for logos, branding, and unlimited commercial projects for you or your clients.

✅ UNLIMITED PRODUCTS FOR SALE
Create and sell merchandise like t-shirts, mugs, and posters with no unit limits.

✅ SOCIAL MEDIA & VIDEO CONTENT
Use for your monetized YouTube, TikTok, Reels, and all social media posts.

⭐ PERFECT FOR A SINGLE USER
The license is for one user and can be installed on two devices 
(e.g., your PC & Laptop).

It’s the best way to legally use the font and support me as a creator.

➡️ Unlock Your Commercial License Instantly Here:
 https://bestfont.gumroad.com/l/fluxboxes
 https://bestfont.gumroad.com/l/fluxboxes

Thanks again and happy creating!
Dian Haniff / Bearytype